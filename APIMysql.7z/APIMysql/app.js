import express from 'express';
import usuario from './src/routers/usuario.router.js'; 
import juego from './src/routers/juego.router.js';
import body_parse from "body-parser"


const servidor = express();

servidor.use(body_parse.json())
servidor.use(body_parse.urlencoded({extended: true}))


servidor.use('/usuario',usuario);
servidor.use('/juego',juego);



servidor.listen(3000,()=>{
    console.log('El servidor se esta ejecutando en el puerto 3000');
});