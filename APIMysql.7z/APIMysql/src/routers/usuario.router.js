import { Router } from "express";

import { listarUsuario ,RegistrarUsuario, eliminarUsuario} from '../controllers/usuario.controller.js'; 

const route = Router();





route.get('/listar',listarUsuario);
route.post('/registrar',RegistrarUsuario);
route.delete('/eliminar:{id}',eliminarUsuario);

export default route;