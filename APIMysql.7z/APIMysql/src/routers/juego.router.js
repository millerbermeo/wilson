import { Router } from "express";
import { listarJuegos, RegistrarJuego} from "../controllers/juego.controller.js";

const router = Router();

router.get('/listar',listarJuegos);
router.post('/registrar',RegistrarJuego);


export default router;