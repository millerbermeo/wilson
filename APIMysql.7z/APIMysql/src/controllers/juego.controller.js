import { pool } from '../database/conexion.js';

export const listarJuegos = async(req,res)=> {

    const [result] = await pool.query('select * from juegos');
    res.status(200).json(result);

};


export const RegistrarJuego = async(req,res)=> {

    try {
        let {nombre, descripcion, imagen, precio} = req.body
  

    let sql = `insert into juegos (nombre, descripcion, imagen, precio) values ('${nombre}', '${descripcion}', '${imagen}', ${precio})`



    let [rows] = await pool.query(sql);
    res.status(201).send(rows);

    if (rows.affectedRows > 0) {
        return res.status(200).json({"mensaje" : "se registro con exito"})
    } else {
        return res.status(404).json({"mensaje" : "usario no registrado"})
    }

    } catch (error) {
        return res.status(500).json({"mensaje" : error.message});
    }




};
