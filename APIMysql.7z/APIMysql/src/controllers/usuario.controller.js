import { pool } from '../database/conexion.js';

export const listarUsuario = async(req,res)=> {

        try{
            const [result] = await pool.query('select * from usuarios');
            
            if(result.length>0){
                return res.status(200).json(result); 
            } else {
                return res.status(404).json({'message': 'No se econtró usuarios'});
            }
            
        }catch(e){
            return res.status(500).json({'message': 'error' + e});
        }

};

export const RegistrarUsuario = async(req,res)=> {

    let {nombres, direccion, telefono, correo, rol} = req.body
  

    let sql = `insert into usuarios (nombres, direccion, telefono, correo, rol) values ('${nombres}', '${direccion}', '${telefono}', '${correo}', '${rol}')`

    // await pool.query(sql, [nombres, direccion, telefono, correo, rol]);

    // res.status(200).json({ mensaje: 'Usuario registrado correctamente' });


    let [rows] = await pool.query(sql);
    res.status(201).send(rows);

    console.log(sql);

};



export const eliminarUsuario  = async (req, res)=> {
    let id = req.params.id
    sql =  `delete from usuarios where id_usuario = ${id}`

    let [rows] = await pool.query(sql)
    if (rows.affectedRows > 0) {
        return res.status(200).json({"mensaje": "usarios eliminado con exito"})
    } else {
        return res.status(403).json({"mensaje": "usarios no eliminado"})
    }
}
